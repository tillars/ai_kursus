with open ("./mpg_nn.csv", "r") as file_in:
    with open ("./mpg_nn_clean.csv", "w") as file_out:
        for lines in file_in:
            vars = lines.split(",")
            #print(vars)
            newline = vars[0:7]
            print(newline)
            
            for ln in range(7):
                file_out.write(str(float(newline[ln]))+"/r")
            
            #file_out.write(str(float(newline[0]))+","+float(newline[1])+","+float(newline[2])+","+float(newline[3])+","+float(newline[4])+","+float(newline[5])+","+float(newline[6]))
                                                                                                          
                                                                                                          