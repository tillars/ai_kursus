# Create your first MLP in Keras
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
import numpy as np
from tensorflow.keras.models import model_from_json


def test_for_dia(testrecord):
    score = loaded_model.predict( np.array( [ testrecord ] ))
    print("forudsigelse på ", testrecord)
    print(score)
    return score

# hent (indlæs) den gemte model igen
print("Model indlæses...")
json_file = open('model.json', 'r')
loaded_model_json = json_file.read()
json_file.close()
loaded_model = model_from_json(loaded_model_json)
# hent vægtning til model
loaded_model.load_weights("model.h5")
loaded_model.compile(loss='binary_crossentropy', optimizer='rmsprop', metrics=['accuracy'])



#tjek model med en record (dataopsamling eller måling) - omkring linje 456
#testrecord = [6,148,72,35,0,33.6,0.627,50]
#test_for_dia(testrecord)


#6,148,72,35,0,33.6,0.627,50,1
#
#with open ("./pid_clean_error.csv", "r") as file_in:
#    with open ("./logout.txt", "w") as logfile:
#        for lines in file_in:
#            ar = lines.split(",")
            
            
#            testrecord = [float(ar[0]),float(ar[1]),float(ar[2]),float(ar[3]),float(ar[4]),float(ar[5]),float(ar[6]),float(ar[7])]
#            print(testrecord)
#            test_res = test_for_dia(testrecord)
#            janej = "ved ikke"
#            if test_res < 0.20:
#                janej = "nej"
#            if test_res > 0.80:
#                janej = "ja"
                
#            logtxt = str(test_res) + " model: " + janej + " dataset: " + str(ar[8]) 
#            print(logtxt)
#            logfile.write(logtxt)
            
            

#testrecord = [13,145,82,19,110,22.2,0.245,57]
#test_for_dia(testrecord)


#testrecord = [10,148,84,48,237,37.6,1.001,51]
#test_for_dia(testrecord)


#testrecord = [17,163,72,41,114,40.9,0.817,47]
#test_for_dia(testrecord)



print("17,163,72,41,114,40.9,0.817,47")
testrecord = [0,163,72,41,114,40.9,0.817,47]
test_for_dia(testrecord)

print("6,148,72,35,0,33.6,0.627,50")
testrecord = [6,148,72,35,0,33.6,0.627,50]
test_for_dia(testrecord)

print("1,93,70,31,0,30.4,0.315,23")
testrecord = [1,93,70,31,0,30.4,0.315,23]
test_for_dia(testrecord)


