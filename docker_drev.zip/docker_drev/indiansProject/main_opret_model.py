# import libs
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
import numpy as np
from tensorflow.keras.models import model_from_json


# indlæs dataset
dataset = np.loadtxt("./dataset_org.csv", delimiter=",")

X = dataset[:,[0,1,2,3,4,5,6,7]]
Y = dataset[:,8]

# opret neuralt netværk (model)

dens_counts = 50
lag = 5
forsog = 180


model = Sequential()
model.add(Dense(12, input_dim=8, activation='relu'))

for loop in range(lag):
    model.add(Dense(dens_counts, activation='relu'))


model.add(Dense(1, activation='sigmoid'))

# kompile model
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
#model.compile(loss='binary_crossentropy', optimizer='nadam', metrics=['accuracy'])
#model.compile(loss='binary_crossentropy', optimizer='sgd', metrics=['accuracy'])
#model.compile(loss='binary_crossentropy', optimizer='adagrad', metrics=['accuracy'])

# tilpas 
model.fit(X, Y, epochs=forsog, batch_size=10, verbose=1)

# tjek model
scores = model.evaluate(X, Y)
print("\n%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))

test = X[0][np.newaxis, :]
score = model.predict( test )

print("Forudsigelse : ", score[0][0])
print("Model gemmes til senere...")

# serialize model til JSON
model_json = model.to_json()
with open("model.json", "w") as json_file:
    json_file.write(model_json)

# serialize vægt til HDF5
model.save_weights("model.h5")

# senere...
print("Senere...")

print("Model indlæses...")

# hent (indlæs) den gemte model igen
json_file = open('model.json', 'r')
loaded_model_json = json_file.read()
json_file.close()
loaded_model = model_from_json(loaded_model_json)
# hent vægtning til model
loaded_model.load_weights("model.h5")

print("Model tjekkes via dataset...")

# tjek model igen
loaded_model.compile(loss='binary_crossentropy', optimizer='rmsprop', metrics=['accuracy'])
score = loaded_model.evaluate(X, Y, verbose=0)
print("%s: %.2f%%" % (loaded_model.metrics_names[1], score[1]*100))

#tjek model med en record (dataopsamling eller måling)

# tjek model igen
loaded_model.compile(loss='binary_crossentropy', optimizer='rmsprop', metrics=['accuracy'])

print("1,148,72,35,0,33.6,0.627,50")
testdataset = [1,148,72,35,0,33.6,0.627,50]

score = loaded_model.predict( np.array( [ testdataset ] ))
print(score)

print("6,148,72,35,0,33.6,0.627,50")

testdataset = [6,148,72,35,0,33.6,0.627,50]

score = loaded_model.predict( np.array( [ testdataset ] ))
print(score)

print("1,93,70,31,0,30.4,0.315,23")
testdataset = [1,93,70,31,0,30.4,0.315,23]

score = loaded_model.predict( np.array( [ testdataset ] ))
print(score)
