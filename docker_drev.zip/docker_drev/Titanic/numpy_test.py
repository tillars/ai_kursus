import numpy as np

# Opret en numpy-array med tal fra 1 til 10
arr = np.arange(1, 11)

# Udskriv arrayet
print("Arrayet er:", arr)

# Beregn gennemsnittet af tallene i arrayet
mean = np.mean(arr)

# Udskriv gennemsnittet
print("Gennemsnittet er:", mean)

# Beregn standardafvigelsen af tallene i arrayet
std_dev = np.std(arr)

# Udskriv standardafvigelsen
print("Standardafvigelsen er:", std_dev)
