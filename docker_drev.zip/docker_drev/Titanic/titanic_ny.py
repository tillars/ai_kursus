#X = df.drop(["index", "Patient Id", "Level"], axis=1).values
#y = df["Level"]

#x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=1/3, random_state=3)

#model = RandomForestClassifier(n_estimators=100, max_depth=5, random_state=1)
#model.fit(X, y)
#predictions = model.predict(X_test)

