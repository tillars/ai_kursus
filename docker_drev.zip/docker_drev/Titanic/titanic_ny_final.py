import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score
from sklearn.model_selection import RandomizedSearchCV, train_test_split
from scipy.stats import randint
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import LabelEncoder
import os


le = LabelEncoder()

df = pd.read_csv("train.csv")
df_test = pd.read_csv("test.csv")
df_test.drop(["PassengerId","Name","Parch","Ticket","Fare","Cabin","Embarked"], axis=1, inplace=True)



encoded = le.fit_transform(df_test['Sex'])
#print(encoded)
# removing the original column 'Purchased' from df
df_test.drop("Sex", axis=1, inplace=True)
# Appending the array to our dataFrame
df_test["Sex"] = encoded
df_test["Age"].fillna(df_test["Age"].mean(),inplace=True)



encoded = le.fit_transform(df['Sex'])
# removing the original column 'Purchased' from df
df.drop("Sex", axis=1, inplace=True)
# Appending the array to our dataFrame
df["Sex"] = encoded
df["Age"].fillna(df["Age"].mean(),inplace=True)


X = df.drop(["PassengerId","Survived","Name","Parch","Ticket","Fare","Cabin","Embarked"], axis=1)
y = df["Survived"]

x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=1/3, random_state=3)

model = RandomForestClassifier(n_estimators=1000, max_depth=1500, random_state=1)
model.fit(x_train, y_train)
predictions = model.predict(df_test)

print(model.score(x_test, y_test))
