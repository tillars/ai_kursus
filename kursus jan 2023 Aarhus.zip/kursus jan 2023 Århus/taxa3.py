
#Dette program skal kunne udregne priser på taxa kørsel

def udregnpris(afstand, taxa_type):
	#taxa_type_lille = 1
	#taxa_type_stor = 2
	
	#y=ax+b
		
	#a
	kr_pr_km_lille = 1
	kr_pr_km_stor = 2

	#b
	start_lille = 20
	start_stor = 50
	
	
	if taxa_type == 1:
		beregn_kr_pr_km = kr_pr_km_lille
		beregn_start = start_lille
		
	elif taxa_type == 2:
		beregn_kr_pr_km = kr_pr_km_stor
		beregn_start = start_stor		
	else:
		beregn_kr_pr_km = 0
		beregn_start = 0		

			
	return (beregn_kr_pr_km * afstand) + beregn_start
	
#print(udregnpris(0,3))		
		
with open("taxa_tabel_pris.csv", "w") as taxafil:
	taxafil.write("afstand,pris_lille,pris_stor\n")

	for afstand in range(0,101):
		str_fil = str(afstand) + "," + str(udregnpris(afstand,1)) + "," + str(udregnpris(afstand,2))
		print(str_fil)
		taxafil.write(str_fil + "\n")
		
			
	
