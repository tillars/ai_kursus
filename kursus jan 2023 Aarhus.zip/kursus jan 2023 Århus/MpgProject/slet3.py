for sensor in "123456789bbbbgggg":
    print(sensor)