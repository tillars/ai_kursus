import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
import math


df = pd.read_csv("mpg.csv")
df = df.drop('name', axis=1)
df = df.replace('?', np.nan)
df = df.dropna()

df2 = df
#df2 = df2.drop('mpg', axis=1)
df2.to_csv("mpg_new.csv")

X = df.drop('mpg', axis=1)
y = df['mpg']



# Init model
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state = 42)
#X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25)

model = LinearRegression(fit_intercept=1)
model.fit(X_train.values,y_train.values) 
print("coef 0")
print(model.coef_[0])

for idx, col_name in enumerate(X_train.columns):
    print("koefficienter for {} er {}".format(col_name, model.coef_[idx]))

# forudsigelse
y_predict = model.predict(X_test.values)


model_mse = mean_squared_error(y_predict, y_test)
print("Hovedfejl : ", model_mse)
print("mpg : ", math.sqrt(model_mse))




y_pred = model.predict([[6,199,90,2648,15,70,1]])
print("Svar på test 0")
print(y_pred[0])

#linje 5
#8,304,150,3433,12,70,1
y_pred = model.predict([[8,304,150,3433,12,70,1]])
print("Svar på test 1")
print(y_pred[0])
