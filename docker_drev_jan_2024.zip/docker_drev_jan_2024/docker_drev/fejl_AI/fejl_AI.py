# importing standard libraries
import pandas as pd
import numpy as np

import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

from sklearn.preprocessing import MinMaxScaler, PowerTransformer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.metrics import roc_curve, roc_auc_score
from sklearn.model_selection import GridSearchCV
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.activations import linear, relu, sigmoid



train_data = pd.read_csv('./train.csv',index_col=0)
test_data = pd.read_csv('./test.csv',index_col=0)
orig_data = pd.read_csv('./machine failure.csv',index_col=0)


#train_data.info()
#train_data.head()
#test_data.info()
#test_data.head()
#orig_data.info()
#orig_data.head()


"""## Defining Categorical Dtype"""

# List of datasets

datasets = [train_data, test_data, orig_data]

#print(datasets[0])

# Columns to convert to categorical
columns = ['Type']

for dataset in datasets:
    for column in columns:
        dataset[column] = dataset[column].astype('category')


#datasets[0]

# Define a dictionary with new column names
new_column_names = {'Air temperature [K]' : 'Air temperature',
                    'Process temperature [K]' : 'Process temperature',
                    'Rotational speed [rpm]' : 'Rotational speed',
                    'Torque [Nm]' : 'Torque',
                    'Tool wear [min]' : 'Tool wear'}

# Rename the columns
train_data = train_data.rename(columns=new_column_names)
test_data = test_data.rename(columns=new_column_names)
orig_data = orig_data.rename(columns=new_column_names)


def compute_engineered_features(data: pd.DataFrame) -> pd.DataFrame:

    """
    Create engineered features to have the dataset model-ready

    Args:
        data Pandas.DataFrame input

    Returns:
        data Pandas.DataFrame with engineered features
    """

    # Create engineered features
    # Create a new columns to distinguish 'young' (U) vs "adult" (A) crabs
    data['Air temperature per Process temperature']  = data['Air temperature'] * data['Process temperature']

    data['Temperature ratio'] = data['Process temperature'] / data['Air temperature']

    data['Toque per Rotational speed'] = data['Torque'] * data['Rotational speed']

    data['Torque Rotational speed ratio'] = data['Torque'] / data['Rotational speed']

    data['Failure sum'] = data[['TWF', 'HDF', 'PWF', 'OSF', 'RNF']].sum(axis=1)

    return data

# Engineering features in train data
train_data = compute_engineered_features(train_data.copy())

# Engineering features in original data
orig_data = compute_engineered_features(orig_data.copy())

# Engineering features in test data
test_data = compute_engineered_features(test_data.copy())

"""## Concatenate Training and Original Datasets"""

full_train_data = pd.concat([train_data, orig_data], axis=0)

"""## Defining Features and Label"""

full_train_data.columns

numerical_features = ['Air temperature',
                      'Process temperature',
                      'Rotational speed',
                      'Torque',
                      'Tool wear',
                      'Air temperature per Process temperature',
                      'Temperature ratio',
                      'Toque per Rotational speed',
                      'Torque Rotational speed ratio',
                      'Failure sum']

categorical_features = ['Type',
                        'TWF',
                        'HDF',
                        'PWF',
                        'OSF',
                        'RNF']

label = ['Machine failure']

"""## Scale and Normalize Numerical Features"""

# Create the pipeline
pipeline = Pipeline([
    ('scaler', MinMaxScaler()),
    ('transformer', PowerTransformer())
])

# Fit and transform the train data using the pipeline
transformed_train_data = pd.DataFrame(pipeline.fit_transform(full_train_data[numerical_features]))

# Scaling removed column names - put them back
transformed_train_data.columns = numerical_features

# Reset index
transformed_train_data.index = full_train_data.index

# Transform test data
transformed_test_data = pd.DataFrame(pipeline.transform(test_data[numerical_features]))

# Scaling removed column names - put them back
transformed_test_data.columns = numerical_features

# Reset index
transformed_test_data.index = test_data.index

"""## Encoding Categorical Features + Concat Transformed Data"""

# Apply one-hot encoding on the 'Type' column in the train set
encoded_type = pd.get_dummies(full_train_data['Type'], prefix='Type')

# Concat encoded_sex to transformed_train_data
transformed_train_data = pd.concat([transformed_train_data, encoded_type], axis=1)

# Apply one-hot encoding on the 'Type' column in the test set
encoded_type = pd.get_dummies(test_data['Type'], prefix='Type')

# Concat encoded_geometry to transformed_test_data
transformed_test_data = pd.concat([transformed_test_data, encoded_type], axis=1)

"""## Splitting Data Between Train and Test Set"""

# Defining a seed
seed = 108

# Define X and y for the training set
X = transformed_train_data
y = np.ravel(full_train_data[label])

# Splitting train dataset into train and test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=seed)

"""<a name="4"></a>
# Model Training
"""

# Define metric(s) to compare the models
metrics = ['AUC_ROC']

# Initialize DataFrame of model performance
performance = pd.DataFrame(columns=metrics)

"""## Logistic Regression

Baseline model
"""

y_train.shape

# Instantiate a LogisticRegression model
model_lr = LogisticRegression(max_iter=1000)

# Fit model to the train set
model_lr.fit(X_train, y_train)

# predict y_pred values
y_pred_lr = model_lr.predict_proba(X_test)[:, 1]

# Compute AUC_ROC metric
auc_roc_lr = roc_auc_score(y_test, y_pred_lr)

print('LogisticRegression AUC_ROC: {}'.format(auc_roc_lr))

# Update 'performance' DataFrame
performance.loc['Logistic Regressor'] = [auc_roc_lr]

"""## Random Forest Classifier"""

# Instantiate a RandomForestClassifier model
model_rfc = RandomForestClassifier(n_estimators=50,
                                   max_depth=3,
                                   class_weight='balanced',
                                   random_state=seed)

# Fit model to the train set
model_rfc.fit(X_train, y_train)

# predict y_pred values
y_pred_rfc = model_rfc.predict_proba(X_test)[:, 1]

# Compute AUC_ROC metric
auc_roc_rfc = roc_auc_score(y_test, y_pred_rfc)

print('RandomForestClassifier AUC_ROC: {}'.format(auc_roc_rfc))

# Update 'performance' DataFrame
performance.loc['Random Forest Classifier'] = [auc_roc_rfc]

# Set random seed
tf.random.set_seed(108)

# Define Neural Network Architecture
model_tf = Sequential(
    [
        Dense(60, input_shape=(13,), activation='relu', name='L1'),
        Dense(30, activation='relu', name='L2'),
        Dense(20, activation='relu', name='L3'),
        Dense(10, activation='relu', name='L4'),
        Dense(5, activation='relu', name='L5'),
        Dense(1, activation='linear', name='L6'),
    ]
)

model_tf.summary()

model_tf.compile(loss=tf.keras.losses.BinaryCrossentropy(from_logits=True),optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),)

history=model_tf.fit(X_train, y_train, epochs=15)

# Generate Prediction
y_pred_tf = model_tf.predict(X_test)

roc_auc_tf = roc_auc_score(y_test, y_pred_tf)
#print(X_test)
print('Neural Network AUC_ROC: {}'.format(roc_auc_tf))

#print(model_tf.predict([[136429,"L50896","L",302.3,311.5,1499,38.0,60,0,0,0,0,0]]))
