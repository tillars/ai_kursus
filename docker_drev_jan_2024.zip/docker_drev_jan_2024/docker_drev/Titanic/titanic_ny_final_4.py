import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score
from sklearn.model_selection import RandomizedSearchCV, train_test_split
from scipy.stats import randint
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import LabelEncoder
import os



le = LabelEncoder()

df = pd.read_csv("train.csv")
df_test = pd.read_csv("test.csv")
#df_test.drop(["PassengerId","Name","Parch","Ticket","Fare","Cabin","Embarked"], axis=1, inplace=True)
df_test.drop(["PassengerId","Name","Parch","Ticket","Fare","Cabin"], axis=1, inplace=True)



encoded = le.fit_transform(df_test['Sex'])
df_test.drop("Sex", axis=1, inplace=True)
df_test["Sex"] = encoded
encoded = le.fit_transform(df_test['Embarked'])
df_test.drop("Embarked", axis=1, inplace=True)
df_test["Embarked"] = encoded

df_test["Age"].fillna(df_test["Age"].mean(),inplace=True)


encoded = le.fit_transform(df['Sex'])
print(encoded)
df.drop("Sex", axis=1, inplace=True)
df["Sex"] = encoded

df['Embarked'] = le.fit_transform(df['Embarked'].astype(str))

encoded = le.fit_transform(df['Embarked'])
print(encoded)
df.drop("Embarked", axis=1, inplace=True)
df["Embarked"] = encoded
print(encoded)


df["Age"].fillna(df["Age"].mean(),inplace=True)


#X = df.drop(["PassengerId","Survived","Name","Ticket","Fare","Cabin","Embarked"], axis=1)
X = df.drop(["PassengerId","Survived","Name","Ticket","Fare","Cabin"], axis=1)
X = X.values # conversion of X  into array

#Org
#PassengerId,Survived,Pclass,Name,Sex,Age,SibSp,Parch,Ticket,Fare,Cabin,Embarked

#efter slet 
#Pclass,Sex,Age,SibSp,Parch

y = df["Survived"]

x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=1/3, random_state=3)

model = RandomForestClassifier(n_estimators=1000, max_depth=1500, random_state=1)
model.fit(x_train, y_train)

predictions = model.predict(x_test)
print("Test af model ", model.score(X, y))

print("Vægtning af kolonner i dataset - Pclass,Sex,Age,SibSp,Parch","Embarked")
print(model.feature_importances_)


#PassengerId,Survived,Pclass,Name,Sex,Age,SibSp,Ticket,Fare,Cabin,Embarked
#Pclass,Sex,Age,SibSp,Parch


'''
print('#1,0,3,"Braund, Mr. Owen Harris",male,22,1,0,A/5 21171,7.25,,S')
datalist = [[3,1,22,1,0]]

result = model.predict(datalist)

if result[0] == 0:
	print("Overlede ikke")
else:
	print("Overlevede")	



print('#2,1,1,"Cumings, Mrs. John Bradley (Florence Briggs Thayer)",female,38,1,0,PC 17599,71.2833,C85,C')
datalist = [[1,0,38,1,0]]
result = model.predict(datalist)

if result[0] == 0:
	print("Overlede ikke")
else:
	print("Overlevede")	



print('#485,1,1,"Bishop, Mr. Dickinson H",male,25,1,0,11967,91.0792,B49,C')
datalist = [[1,1,25,1,0]]
result = model.predict(datalist)

if result[0] == 0:
	print("Overlede ikke")
else:
	print("Overlevede")	




print('#36,0,1,"Holverson, Mr. Alexander Oskar",male,42,1,0,113789,52,,S')
datalist = [[1,1,42,1,0]]
result = model.predict(datalist)

if result[0] == 0:
	print("Overlede ikke")
else:
	print("Overlevede")	

'''



#Indtast værdier

#Pclass,Sex,Age,SibSp,Parch

while True:
	
	print("Indtast følgende værdier:")
	pclass = int(input("Pclass "))
	sex = int(input("sex "))
	age = int(input("age "))
	sib = int(input("SibSp "))
	par = int(input("parch "))

	datalist = [[pclass,sex,age,sib,par]]
	result = model.predict(datalist)

	if result[0] == 0:
		print("Overlede ikke")
	else:
		print("Overlevede")	







