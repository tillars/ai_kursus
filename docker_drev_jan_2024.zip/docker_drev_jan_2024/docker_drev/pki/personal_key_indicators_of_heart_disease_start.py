# Opgave:
# 
# Indlaes og rens data
#
# Traen en model som hvor y = HeartDisease og x = er resten af kollonerne (BMI,Smoking,AlcoholDrinking,Stroke,PhysicalHealth,MentalHealth,DiffWalking,Sex,AgeCategory,Race,Diabetic,PhysicalActivity,GenHealth,SleepTime,Asthma,KidneyDisease,SkinCancer). 
#
#



####Eksempler paa import
#import numpy as np
#import pandas as pd



####Indlaeser data fra cvs fil
#data = pd.read_csv('./heart_2020_cleaned.csv')
#print(data.head(15))



####Rens data, udsnit:

#HeartDisease,BMI,Smoking,AlcoholDrinking,Stroke,PhysicalHealth,MentalHealth,DiffWalking,Sex,AgeCategory,Race,Diabetic,PhysicalActivity,GenHealth,SleepTime,Asthma,KidneyDisease,SkinCancer
#No,16.6,Yes,No,No,3.0,30.0,No,Female,55-59,White,Yes,Yes,Very good,5.0,Yes,No,Yes
#No,20.34,No,No,Yes,0.0,0.0,No,Female,80 or older,White,No,Yes,Very good,7.0,No,No,No
#No,26.58,Yes,No,No,20.0,30.0,No,Male,65-69,White,Yes,Yes,Fair,8.0,Yes,No,No
#No,24.21,No,No,No,0.0,0.0,No,Female,75-79,White,No,No,Good,6.0,No,No,Yes
#No,23.71,No,No,No,28.0,0.0,Yes,Female,40-44,White,No,Yes,Very good,8.0,No,No,No
#Yes,28.87,Yes,No,No,6.0,0.0,Yes,Female,75-79,Black,No,No,Fair,12.0,No,No,No
#No,21.63,No,No,No,15.0,0.0,No,Female,70-74,White,No,Yes,Fair,4.0,Yes,No,Yes
#No,31.64,Yes,No,No,5.0,0.0,Yes,Female,80 or older,White,Yes,No,Good,9.0,Yes,No,No
#No,26.45,No,No,No,0.0,0.0,No,Female,80 or older,White,"No, borderline diabetes",No,Fair,5.0,No,Yes,No
#No,40.69,No,No,No,0.0,0.0,Yes,Male,65-69,White,No,Yes,Good,10.0,No,No,No
#Yes,34.3,Yes,No,No,30.0,0.0,Yes,Male,60-64,White,Yes,No,Poor,15.0,Yes,No,No
#No,28.71,Yes,No,No,0.0,0.0,No,Female,55-59,White,No,Yes,Very good,5.0,No,No,No
#No,28.37,Yes,No,No,0.0,0.0,Yes,Male,75-79,White,Yes,Yes,Very good,8.0,No,No,No
#No,28.15,No,No,No,7.0,0.0,Yes,Female,80 or older,White,No,No,Good,7.0,No,No,No



####Nu skal x og y saettes

#allcol = [col for col in data.columns]
#allcol.remove('HeartDisease')

#x = data[allcol]
#y = data['HeartDisease']



####Opdel data i traening og test dataset, husk "from sklearn.model_selection import train_test_split" kan bruges



####Vi er klar til at oprette, compile og fit vore model.
####Folgende kan bruges
#import tensorflow as tf
#from tensorflow import keras
#from tensorflow.keras import layers


####Lav nu en forudsigelse med vores test dataset som vi oprettese tidligere


####Tjek hvor god vores nye traenede model er blevet
####Folgende kan bruges
#from sklearn.metrics import mean_absolute_error
# vi skal lave en sammenligning med y_test og y_predict

#print(accuracy)


#The end
