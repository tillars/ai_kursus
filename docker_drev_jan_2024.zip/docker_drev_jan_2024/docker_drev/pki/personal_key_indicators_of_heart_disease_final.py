import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

import os


data = pd.read_csv('./heart_2020_cleaned.csv')
print(data.head(15))



data['Diabetic'].unique()

dib = {'Yes':0.80, 'No':0.00, 'No, borderline diabetes':0.5, 'Yes (during pregnancy)':1.00}
data['Diabetic'] = data['Diabetic'].apply(lambda x: dib[x])
data['Diabetic'] = data['Diabetic'].astype('float')

data['AgeCategory'].unique()

AgeCategoryu = {'55-59':57, '80 or older':80, '65-69':67, '75-79':77, '40-44':42, '70-74':72,
       '60-64':62, '50-54':52, '45-49':47, '18-24':21, '35-39':37, '30-34':32, '25-29':27}
data['AgeCategory'] = data['AgeCategory'].apply(lambda x: AgeCategoryu[x])
data['AgeCategory'] = data['AgeCategory'].astype('float')

print(data.head(15))

import matplotlib.pyplot as plt
#import seaborn as sns

data['Race'].unique()

print(data.head(15))

from sklearn.preprocessing import LabelEncoder

si = LabelEncoder()
si.fit(data['HeartDisease'])
data['HeartDisease'] = si.transform(data['HeartDisease'])

print(data.head(15))

cat = [col for col in data.columns if data[col].dtypes == 'object']
cat

# Commented out IPython magic to ensure Python compatibility.
# %matplotlib inline
#plt.figure(figsize = (16,8))
#for i in cat:
#    sns.catplot(y = 'HeartDisease',x = i,hue = 'Sex',data = data,kind = 'bar')

#for i in cat:
#    sns.catplot(y = 'HeartDisease',x = i,hue = 'Sex',data = data,kind = 'point')



allc = [col for col in data.columns]
imp = list(set(allc)-set(cat))

si = LabelEncoder()
for i in cat:
    si.fit(data[i])
    data[i] = si.transform(data[i])

print(data.shape)

allcol = [col for col in data.columns]

allcol.remove('HeartDisease')

x = data[allcol]
y = data['HeartDisease']

print(x.head(15))

data['AgeCategory'] = data['AgeCategory']/80

data['AgeCategory']

from sklearn.model_selection import train_test_split

x_train,x_test,y_train,y_test = train_test_split(x,y)

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

print("#################")

model = keras.Sequential([
    layers.Dense(units = 51,activation = 'relu',input_shape = [17]),
    layers.Dense(units = 81,activation = 'relu'),
    layers.Dense(units = 81,activation = 'relu'),
    layers.Dense(units = 81,activation = 'relu'),
    layers.Dense(units = 81,activation = 'relu'),
    layers.Dense(units = 81,activation = 'relu'),
    layers.Dense(units = 81,activation = 'relu'),
    layers.Dense(units = 81,activation = 'relu'),
    layers.Dense(units = 81,activation = 'relu'),
    layers.Dense(units = 1,activation = 'sigmoid')
])

#    loss = 'mse',
model.compile(
    optimizer = 'adam',

    loss = 'binary_crossentropy',
    metrics = ['accuracy']
)

model.fit(x_train,y_train,epochs = 2)

print("Vægtning af x inputs...")
#print(model.feature_importances_)


y_predict = model.predict(x_test)

#print(y_test)

print(y_predict)

from sklearn.metrics import mean_absolute_error

mae = mean_absolute_error(y_test,y_predict)
accuracy = (1-mae)*100
print("accuracy")
print(accuracy)

print(model.summary())
