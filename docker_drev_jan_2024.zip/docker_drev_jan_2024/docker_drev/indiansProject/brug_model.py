# Create your first MLP in Keras
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
import numpy as np
from tensorflow.keras.models import model_from_json


def test_for_dia(testrecord):
    score = loaded_model.predict( np.array( [ testrecord ] ))
    print("forudsigelse på ", testrecord)
    print(score)
    return score

# hent (indlæs) den gemte model igen
print("Model indlæses...")
json_file = open('model.json', 'r')
loaded_model_json = json_file.read()
json_file.close()
loaded_model = model_from_json(loaded_model_json)
# hent vægtning til model
loaded_model.load_weights("model.h5")
loaded_model.compile(loss='binary_crossentropy', optimizer='rmsprop', metrics=['accuracy'])

print("17,163,72,41,114,40.9,0.817,47")
testrecord = [17,163,72,41,114,40.9,0.817,47]
test_for_dia(testrecord)

print("6,148,72,35,0,33.6,0.627,50")
testrecord = [6,148,72,35,0,33.6,0.627,50]
test_for_dia(testrecord)

print("1,93,70,31,0,30.4,0.315,23")
testrecord = [1,93,70,31,0,30.4,0.315,23]
test_for_dia(testrecord)


