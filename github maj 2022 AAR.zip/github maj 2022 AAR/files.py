#Dette program skriver og laeser filer
from datetime import datetime
import time
import random



def readsensor_logdata(sensor, logfile):
    logfile.write(sensor + ":" + str(random.randint(-50, 50)) + "\r")


now = datetime.now()
now = now.strftime('%d/%m/%Y %H:%M:%S')

with open ('log.txt', 'w') as logfile:
    logfile.write('Logfile, oprettet den ' + now + "\r")
    #readsensor_logdata("Sensor1", logfile)

    for sensor in range(10):
        readsensor_logdata("Sensor" + str(sensor), logfile)
        print("Loop " + str(sensor))
        time.sleep(1)

	

print("Vi indlaeser file")


with open ('log.txt', 'r') as logfile:
	for lines in logfile:
		print(lines, end="")
