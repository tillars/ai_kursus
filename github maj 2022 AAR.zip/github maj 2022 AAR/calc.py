

def calc_areal2(l, b):
    areal_lokal = l*b
    return areal_lokal


def calc_areal(l, b):
    return l*b

print(calc_areal(10, 10))
print(calc_areal(20, 20))
print(calc_areal(30, 30))
print(calc_areal(40, 40))


areal = calc_areal(40, 40)

areal2 = calc_areal(50, calc_areal(40, 40))


nyt_areal = calc_areal2(30, 20)

print(nyt_areal)

