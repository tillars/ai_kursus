with open ("./pima-indians-diabetes.csv", "r") as file_in:
    with open ("./pid_clean.csv", "w") as file_out:
        with open ("./pid_clean_error.csv", "w") as file_out_error: 
            for lines in file_in:
                vars = lines.split(",")
                
                if (vars[1] != "0") and (vars[2] != "0") and (vars[3] != "0") and (vars[4] != "0") and (vars[5] != "0") and (vars[6] != "0") and (vars[7] != "0"):
                    file_out.write(lines)
                    print(lines)
                else:
                    file_out_error.write(lines)
                    print(lines)
            
