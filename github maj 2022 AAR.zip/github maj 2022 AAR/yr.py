import urllib.request
from urllib.request import Request, urlopen
import json

def get_data():
    url = 'https://api.met.no/weatherapi/locationforecast/2.0/compact?lat=59.93484&lon=10.72084&altitude=59'
    req = Request(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0'})
    res = urlopen(req).read()

    print(res)
    return res

with open("/home/kursus/vejr.json", "w") as file:
    data = str(get_data(), "UTF-8")
    print(data)
    jsondata = json.loads(data)
    
    print(json.dumps(jsondata, indent=4, sort_keys=True))
    file.write(data)

print ("End")

