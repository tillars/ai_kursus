

str1="abcdefg"


for bogs in str1:
    print(bogs)
    print("-")
