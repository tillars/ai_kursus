with open ("./pima-indians-diabetes.csv", "r") as file_in:
    with open ("./pid_clean.csv", "w") as file_out:
        for lines in file_in:
            vars = lines.split(",")
            #print(vars)
            #newline = vars[0:7]
            #print(newline)
            
            #for ln in range(7):
            #    file_out.write(str(float(newline[ln]))+"/r")