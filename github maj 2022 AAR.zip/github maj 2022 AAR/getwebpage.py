import urllib.request

page = urllib.request.urlopen('http://www.teknologisk.dk')
print(page.read())