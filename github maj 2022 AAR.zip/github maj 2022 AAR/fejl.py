t1=1
t2=1

res = 0

if (t1==t2):
    res = 10
    print(res)
    
print(res)