# import libs
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
import numpy as np
from tensorflow.keras.models import model_from_json


dataset = np.loadtxt("/home/MpgProject/mpg_new.csv", delimiter=",")

X = dataset[:,[2,3,4,5,6,7,8]]
Y = dataset[:,1]

# opret neuralt netværk (model)

#beste 200, 10 
dens_counts = 200
lag = 5
forsog = 100

model = Sequential()
model.add(Dense(7, input_dim=7, activation='relu'))

for loop in range(lag):
    model.add(Dense(dens_counts, activation='relu'))


#model.add(Dense(10000, activation='relu', dtype='float32'))


#model.add(Dense(1000, activation='sigmoid'))
#model.add(Dense(1, activation='linear')) 
# Compile model
#model.compile(loss='sparse_categorical_crossentropy', optimizer='nadam', metrics=['accuracy'])
model.add(Dense(1, activation='linear'))  # one neuron, linear activation  


# kompile model
model.compile(loss='mse', optimizer='nadam')  
#model.compile(loss='sgd', optimizer='adam', metrics=['accuracy'])
#model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
#model.compile(loss='binary_crossentropy', optimizer='nadam', metrics=['accuracy'])
#model.compile(loss='binary_crossentropy', optimizer='sgd', metrics=['accuracy'])
#model.compile(loss='binary_crossentropy', optimizer='adagrad', metrics=['accuracy'])

# tilpas 
model.fit(X, Y, epochs=forsog, batch_size=2, verbose=1)

scores = model.evaluate(X, Y)
#print("\n%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))

test = X[0][np.newaxis, :]
score = model.predict( test )

print("Forudsigelse : ", score[0][0])
print("Model gemmes til senere...")

# serialize model til JSON
model_json = model.to_json()
with open("model.json", "w") as json_file:
    json_file.write(model_json)

# serialize vægt til HDF5
model.save_weights("model.h5")

# senere...
print("Senere...")

#0,18.0,8,307.0,130,3504,12.0,70,1
y_pred = model.predict([[8,307.0,130,3504,12.0,70,1]])
print("Svar på test 0")
print(y_pred[0])

#185,26.0,4,98.0,79,2255,17.7,76,1
y_pred = model.predict([[4,98.0,79,2255,17.7,76,1]])
print("Svar på test 0")
print(y_pred[0])



